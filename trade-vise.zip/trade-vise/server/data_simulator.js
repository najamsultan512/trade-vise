function broadcast(wss, msg) {
  const s = JSON.stringify(msg);
  wss.clients.forEach(c => {
    if (c.readyState === c.OPEN) c.send(s);
  });
}

function startSimulator(wss) {
  let price = 30000;
  let currentCandle = null;

  function startNewCandle(ts) {
    currentCandle = {
      time: Math.floor(ts / 1000),
      open: price,
      high: price,
      low: price,
      close: price
    };
  }

  let lastCandleTime = Math.floor(Date.now() / 60000) * 60000;
  startNewCandle(lastCandleTime);

  setInterval(() => {
    const delta = (Math.random() - 0.5) * 200;
    price = Math.max(1, price + delta);
    const size = +(Math.random() * 5).toFixed(3);

    const trade = {
      type: 'trade',
      symbol: 'BTCUSD',
      price: +price.toFixed(2),
      size,
      side: Math.random() > 0.5 ? 'buy' : 'sell',
      time: Date.now()
    };

    const now = Date.now();
    const candleTime = Math.floor(now / 60000) * 60000;

    if (candleTime !== currentCandle.time * 1000) {
      broadcast(wss, { type: 'candle', candle: currentCandle });
      startNewCandle(candleTime);
    }

    currentCandle.close = trade.price;
    currentCandle.high = Math.max(currentCandle.high, trade.price);
    currentCandle.low = Math.min(currentCandle.low, trade.price);

    broadcast(wss, trade);

    if (Math.random() < 0.1) {
      const ob = generateOrderBook(price);
      broadcast(wss, { type: 'orderbook', data: ob });
    }
  }, Math.random() * 800 + 200);
}

function generateOrderBook(mid) {
  const asks = [], bids = [];
  for (let i = 1; i <= 6; i++) {
    asks.push({ price: +(mid + i * (Math.random() * 30 + 5)).toFixed(2), size: +(Math.random() * 5).toFixed(3) });
    bids.push({ price: +(mid - i * (Math.random() * 30 + 5)).toFixed(2), size: +(Math.random() * 5).toFixed(3) });
  }
  return { asks, bids, time: Date.now() };
}

module.exports = { startSimulator };
