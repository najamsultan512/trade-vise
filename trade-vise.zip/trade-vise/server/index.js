const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { startSimulator } = require('./data_simulator');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'ok', app: 'Trade Vise simulator' }));

app.get('/history/:symbol', (req, res) => {
  const symbol = req.params.symbol || 'BTCUSD';
  const now = Date.now();
  const bars = [];
  let price = 30000;
  for (let i = 200; i > 0; i--) {
    const t = now - i * 60 * 1000;
    const o = price + (Math.random() - 0.5) * 200;
    const c = o + (Math.random() - 0.5) * 200;
    const h = Math.max(o, c) + Math.random() * 100;
    const l = Math.min(o, c) - Math.random() * 100;
    bars.push({ time: Math.floor(t / 1000), open: +o.toFixed(2), high: +h.toFixed(2), low: +l.toFixed(2), close: +c.toFixed(2) });
    price = c;
  }
  res.json({ symbol, bars });
});

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', ws => {
  console.log('Client connected');
  ws.send(JSON.stringify({ type: 'welcome', msg: 'Connected to Trade Vise simulator' }));
});

startSimulator(wss);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
