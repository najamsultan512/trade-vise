# Trade Vise

Simple demo of Trade Vise — a trading graph web app (React frontend + Node.js simulator backend).

## Running locally

1. Server:
```bash
cd server
npm install
npm start
```

2. Client:
```bash
cd client
npm install
npm run dev
```

Open http://localhost:5173
