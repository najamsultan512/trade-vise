import React, { useEffect, useState } from 'react';

export default function TradeFeed() {
  const [trades, setTrades] = useState([]);

  useEffect(() => {
    const onMessage = e => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === 'trade') {
          setTrades(t => [msg, ...t].slice(0, 60));
        }
      } catch {}
    };
    const ws = new WebSocket('ws://localhost:4000');
    ws.addEventListener('message', onMessage);
    return () => ws.close();
  }, []);

  return (
    <div className="panel-box">
      <div className="title">Trade Feed</div>
      <div className="trade-list">
        {trades.map((t, i) => (
          <div className="trade-item" key={i}>
            <div style={{flex:1}} className={t.side === 'buy' ? 'buy' : 'sell'}>{t.side} {t.size}</div>
            <div style={{flex:1, textAlign:'right', fontFamily:'monospace'}}>{t.price.toFixed(2)}</div>
          </div>
        ))}
        {trades.length===0 && <div style={{color:'#6b7f92'}}>Waiting for trades...</div>}
      </div>
    </div>
  );
}
