import React, { useEffect, useState } from 'react';

export default function OrderBook() {
  const [ob, setOb] = useState({ asks: [], bids: [] });

  useEffect(() => {
    const handler = (e) => {
      setOb(e.detail);
    };
    window.addEventListener('ob_update', handler);
    return () => window.removeEventListener('ob_update', handler);
  }, []);

  return (
    <div className="panel-box">
      <div className="title">Order Book (snapshot)</div>
      <div className="orderbook">
        <div className="ob-column">
          <div style={{color:'#9aa7bb',marginBottom:6}}>Asks</div>
          {ob.asks.map((a, i) => (
            <div className="ob-row" key={i}>
              <div style={{color:'#ff6b6b'}}>{a.price}</div>
              <div style={{color:'#9aa7bb'}}>{a.size}</div>
            </div>
          ))}
        </div>

        <div className="ob-column">
          <div style={{color:'#9aa7bb',marginBottom:6}}>Bids</div>
          {ob.bids.map((b, i) => (
            <div className="ob-row" key={i}>
              <div style={{color:'#00ffab'}}>{b.price}</div>
              <div style={{color:'#9aa7bb'}}>{b.size}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
