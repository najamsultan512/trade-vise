import React, { useEffect, useRef, useState } from 'react';
import { createChart } from 'lightweight-charts';

export default function Chart({ wsUrl }) {
  const chartRef = useRef();
  const candleSeriesRef = useRef();
  const wsRef = useRef(null);
  const [trades, setTrades] = useState([]);

  useEffect(() => {
    const chart = createChart(chartRef.current, {
      width: chartRef.current.clientWidth,
      height: 500,
      layout: { backgroundColor: '#0b1220', textColor: '#E6EEF6' },
      grid: { vertLines: { visible: false }, horzLines: { color: '#132032' } },
      timeScale: { timeVisible: true, secondsVisible: false }
    });

    const candleSeries = chart.addCandlestickSeries({
      upColor: '#00ffab', downColor: '#ff6b6b', borderDownColor: '#ff6b6b', borderUpColor: '#00ffab',
      wickDownColor: '#ff6b6b', wickUpColor: '#00ffab'
    });
    candleSeriesRef.current = candleSeries;

    const resize = () => chart.applyOptions({ width: chartRef.current.clientWidth });
    window.addEventListener('resize', resize);

    fetch('http://localhost:4000/history/BTCUSD').then(r => r.json()).then(data => {
      const bars = data.bars.map(b => ({ time: b.time, open: b.open, high: b.high, low: b.low, close: b.close }));
      candleSeries.setData(bars);
    }).catch(console.warn);

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    ws.addEventListener('open', () => console.log('WS open'));
    ws.addEventListener('message', evt => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.type === 'trade') {
          setTrades(t => [msg, ...t].slice(0, 50));
        } else if (msg.type === 'candle') {
          candleSeries.update({
            time: msg.candle.time,
            open: msg.candle.open,
            high: msg.candle.high,
            low: msg.candle.low,
            close: msg.candle.close
          });
        } else if (msg.type === 'orderbook') {
          window.dispatchEvent(new CustomEvent('ob_update', { detail: msg.data }));
        }
      } catch (e) { console.error(e); }
    });

    return () => {
      window.removeEventListener('resize', resize);
      ws.close();
      chart.remove();
    };
  }, [wsUrl]);

  return (
    <div style={{height:'100%'}}>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
        <div style={{color:'#9aa7bb'}}>BTC / USD</div>
        <div style={{color:'#9aa7bb'}}>Live (simulator)</div>
      </div>
      <div ref={chartRef} style={{width:'100%', height:500}} />
      <div className="panel-box" style={{marginTop:8}}>
        <div className="title">Recent trades</div>
        <div className="trade-list">
          {trades.map((t, i) => (
            <div key={i} className="trade-item">
              <div className={t.side === 'buy' ? 'buy' : 'sell'}>
                {t.side.toUpperCase()} {t.size}
              </div>
              <div style={{color:'#9aa7bb'}}>{new Date(t.time).toLocaleTimeString()}</div>
              <div style={{fontFamily:'monospace'}}>{t.price.toFixed(2)}</div>
            </div>
          ))}
          {trades.length===0 && <div style={{color:'#6b7f92'}}>No trades yet (waiting for simulator)</div>}
        </div>
      </div>
    </div>
  );
}
