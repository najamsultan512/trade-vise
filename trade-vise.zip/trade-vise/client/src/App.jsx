import React from 'react';
import Chart from './components/Chart';
import TradeFeed from './components/TradeFeed';
import OrderBook from './components/OrderBook';

export default function App() {
  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">Trade Vise</div>
        <div className="owner">Owner: You</div>
      </header>

      <main className="main-grid">
        <section className="chart-panel">
          <Chart wsUrl="ws://localhost:4000" />
        </section>

        <aside className="side-panel">
          <OrderBook />
          <TradeFeed />
        </aside>
      </main>

      <footer className="footer">
        Demo prototype • Use real market APIs to replace simulator for production
      </footer>
    </div>
  );
}
